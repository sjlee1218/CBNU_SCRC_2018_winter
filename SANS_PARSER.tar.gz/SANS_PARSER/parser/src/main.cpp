#include <iostream>
#include <string>
#include "parser_vercpp.hpp"

using namespace std;

int main(int argc, char *argv[])
{

    if (argc != 3)
    {
        std::cerr << "Argument Failed : parser_node [port] [baudrate]" << std::endl;
        return -1;
    }

    std::string portname = argv[1];
    std::string baud_str = argv[2];
    int baudrate = atoi(baud_str.c_str());

    ublox_parser cUblox(portname, baudrate);
    ublox_parser::PARSING_TYPEDEF_UBX_M8P_PVT globalPVT;


    while (cUblox.isInit)
    {
        cUblox.run();

        if (cUblox.valid() == ublox_parser::PARSING_SUCCESS_)
        {
            cUblox.copyTo(&globalPVT);
            std::cout<< globalPVT.lat << ", " << globalPVT.lon << ", " << globalPVT.height << std::endl;

        }
    }


    return 1;
}
